# Cogs181
Repository for Cogs181 Deep Learning final project

util.py is for XNOR NIN, SOURCE https://github.com/jiecaoyu/XNOR-Net-PyTorch
binarized_modules and vgg_cifar10_binary are for BNN VGG, SOURCE https://github.com/itayhubara/BinaryNet.pytorch

CSVs for ModelStats are in csvs.zip
